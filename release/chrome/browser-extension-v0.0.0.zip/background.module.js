// src/background.module.ts
console.log('Hello, Background!');
