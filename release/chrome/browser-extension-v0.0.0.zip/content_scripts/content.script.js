(() => {
  // src/content_scripts/content.script.ts
  console.log('Hello, Content Script!');
})();
