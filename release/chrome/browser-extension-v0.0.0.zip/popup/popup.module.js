// src/popup/popup.module.ts
console.log('Hello, Popup!');
